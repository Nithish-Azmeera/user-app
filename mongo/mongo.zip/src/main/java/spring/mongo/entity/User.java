package spring.mongo.entity;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="user")
public class User {

	 
	@Id
	private String uname;
	private String ulocation;
	private String uoccupation;
	private int uage;
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getUlocation() {
		return ulocation;
	}
	public void setUlocation(String ulocation) {
		this.ulocation = ulocation;
	}
	public String getUoccupation() {
		return uoccupation;
	}
	public void setUoccupation(String uoccupation) {
		this.uoccupation = uoccupation;
	}
	public int getUage() {
		return uage;
	}
	public void setUage(int uage) {
		this.uage = uage;
	}
	
	
}
